import numpy as np
import math
import datetime
import  pandas as pd
from sklearn.preprocessing import StandardScaler

class train():
    def __init__(self, Parameters, shape, R):
        self.eta = Parameters[0]
        I, J= shape
        # 初始化 S, D, T
        self.P= np.random.rand(I, R)
        self.Q = np.random.rand(J, R)
        # self.T = np.random.rand(K, R)
        # 记录最佳的 S, D, T
        self.best_Q = np.zeros([I, R])
        self.best_P = np.zeros([J, R])
        # self.best_T = np.zeros([K, R])
        self.best_tol = 0
        self.best_loss = float('inf')
        self.best_n = float('inf')

    def train(self, train_indices, valid_indices, num_epochs=100, epsilon=0.01):
        tol = float('inf')
        last_loss = float('inf')
        obj = float('inf')
        n = 1
        # 收敛判断
        conv_cout = 0
        # 判断是否争当振荡
        Osc_count = 0
        while n < num_epochs:
            [self.P, self.Q, self.T] = update(self.P, self.Q, [self.eta], train_indices)
            if n == 1:
                rmse, mae = metrics(self.P, self.Q, valid_indices)
                last_loss = rmse
                self.best_loss = last_loss
                self.best_n = n
                print('验证集:迭代轮数:%d,损失:%f' % (n, last_loss))
                self._save_best()
            if n > 1:
                rmse, mae = metrics(self.P, self.Q, valid_indices)
                # 使用rmse或者mae来判断训练是否收敛
                loss = rmse
                # tol为对比上一次训练loss的改变量,用这个来判断是否收敛.如果连续几轮训练改变量都很小你可以认为已经收敛
                tol = last_loss - loss
                print('验证集:迭代轮数:%d,损失:%f,tol:%f' % (n, loss, tol))
                if (tol > epsilon):
                    conv_cout = 0
                    #  判断当前obj是否小于最佳obj
                    if loss < self.best_loss:
                        self.best_loss = loss
                        self.best_n = n
                        self.best_tol = tol
                        # 保存最佳的S D T
                        self._save_best()
                else:
                    conv_cout = conv_cout + 1
                    if conv_cout == 5:
                        break
                    if Osc_count == 20:
                        end_time = datetime.datetime.now()
                        self.time_cost = (end_time - start_time).seconds
                        break
                last_loss = loss
            n = n + 1

    # 给实例对象调用的,传入测试集
    def metrics(self, indices_set):
        [RMSE, MSE] = metrics(self.best_P, self.best_Q, self.T, indices_set)
        return [RMSE, MSE]

    def get_current_info(self):
        return [self.best_loss, self.best_n, self.best_tol]

    def _save_best(self):
        self.best_P = self.P.copy()
        self.best_Q = self.Q.copy()
        # self.best_T = self.T.copy()


def update(P, Q, Parameters, train_indices):
    eta = Parameters[0]
    clip_value = .7  # 梯度裁剪阈值
    lambda_reg = 0.001  # L2正则化强度

    for [i, j, Y] in train_indices:
        # k = int(k)
        i = int(i)
        j = int(j)
        Y_hat = get_Y_hat(P[i], Q[j])

        # 检查Y_hat和Y是否为有限值
        if np.isfinite(Y_hat) and np.isfinite(Y):
            # 计算更新值
            update_P = -eta * ((Y_hat - Y) * Q[j]) - eta * lambda_reg * P[i]
            update_Q = -eta * ((Y_hat - Y) * P[i]) - eta * lambda_reg * Q[j]

            # 更新S, D, T
            P[i] += update_P
            Q[j] += update_Q
        else:
            print("Non-finite values detected, skipping update for index:", [ i, j])
            print("Y_hat:", Y_hat)
            print("Y:", Y)

    return [P,Q]




# 获得y_hat
def get_Y_hat(P_i, Q_j):
    return np.sum(P_i * Q_j)



def metrics(P, Q, indices):
    """
    传入两个张量和需要测试的元素下标
    """
    RMSE = 0
    MSE = 0
    test_num = len(indices)
    for [i, j, Y] in indices:
        # k = int(k)
        i = int(i)
        j = int(j)
        Y_hat = np.sum(P[i] * Q[j])
        RMSE = RMSE + (Y - Y_hat) ** 2
        MSE = MSE + abs(Y - Y_hat)
    RMSE = math.sqrt(RMSE / test_num)
    MSE = MSE / test_num
    return [RMSE, MSE]


def getData():

    df = pd.read_csv(r'D:\WeChat Files\wxid_cqxi4vjxzbpd21\FileStorage\File\2024-05\WinGNN\WinGNN\data.csv')
    data = df.iloc[:,2:]
    data['New_Column'] = 0
    data['New_Column1'] = 0
    # 数据标准化
    scaler = StandardScaler()
    data = scaler.fit_transform(data)
    tensor = data.reshape(-1,148,7)


    k, i, j = tensor.shape

    # 创建k, i, j的索引数组,形状为(k, i, j，3) 3列的值分别对应 k,i,j
    indices = np.indices((k, i, j)).reshape(3, -1).T

    # 张量展平
    values = tensor.flatten()

    # 移除values中的NaN值
    indices = indices[~np.isnan(values)]  # 使用逻辑索引来移除NaN值
    values = values[~np.isnan(values)]  # 同样移除对应的NaN值

    # 堆叠为 k ,i, j , value 这样的数组
    result_array = np.column_stack((indices, values))
    # 检查result_array中是否包含NaN值
    if np.isnan(result_array).any():
        print("警告：result_array中存在NaN值。")
        # 如果需要，可以移除包含NaN的行
        result_array = result_array[~np.isnan(result_array).any(axis=1)]
        print("已移除包含NaN的行。")
    else:
        print("result_array中没有NaN值。")
    # Manual normalization
    min_val = np.min(result_array[:, 3])  # Get min value of the 'values'
    max_val = np.max(result_array[:, 3])  # Get max value of the 'values'

    # Normalize values to [0, 1]
    result_array[:, 3] = 5*(result_array[:, 3] - min_val) / (max_val - min_val)

    # Shuffle the array
    np.random.shuffle(result_array)

    # Split into training, validation, and testing sets
    total_rows = result_array.shape[0]
    train_size = int(0.6 * total_rows)
    val_size = int(0.2 * total_rows)

    # Split into sets
    train_set = result_array[:train_size, :]
    val_set = result_array[train_size:train_size + val_size, :]
    test_set = result_array[train_size + val_size:, :]
    return train_set, val_set, test_set, tensor.shape



# 按间距中的绿色按钮以运行脚本。
if __name__ == '__main__':
    # 学习率
    eta = 0.001
    # 隐藏特征维度
    R = 10
    # 最大迭代次数
    max_iter_num = 100
    # 收敛临界值
    epsilon = 1e-6
    train_set, val_set, test_set, shape = getData()

    model = LFT([eta], shape, R)
    # 参数分别为:训练集,验证集 ,最大迭代次数,收敛临界值
    model.train(train_set, val_set, max_iter_num, epsilon)

    # 获取训练过程中的loss,迭代次数,和tol
    loss, n, tol = model.get_current_info()

    # 传入测试集
    rmse, mae = model.metrics(test_set)

    print(f'rmse:{rmse},mae:{mae},loss:{loss},迭代次数:{n},tol:{tol}')

# 访问 https://www.jetbrains.com/help/pycharm/ 获取 PyCharm 帮助
