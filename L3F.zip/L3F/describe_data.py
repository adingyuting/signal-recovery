import pandas as pd
import numpy as np

# 1. 读取数据（假设数据文件名为 airquality.csv）
file_path = r'D:\WeChat Files\wxid_cqxi4vjxzbpd21\FileStorage\File\2025-02\Data-1\Data\airquality.csv'
data_df = pd.read_csv(file_path)

# 2. 确保数据按时间戳排序，并填充缺失的时间点
# 假设数据中有 'timestamp' 列，格式为 'YYYY-MM-DD HH:MM:SS'
data_df['time'] = pd.to_datetime(data_df['time'])
data_df = data_df.sort_values(by='time')

# 设置时间范围为20140501到20150430
start_time = pd.Timestamp('2014-05-01 00:00:00')
end_time = pd.Timestamp('2015-04-26 6:00:00')

# 创建时间范围，确保每小时有一个时间点
all_hours = pd.date_range(start=start_time, end=end_time, freq='H')

# 为每个站点创建完整的时序数据
station_list = []
for i in range(35):
    j = 1001 + i
    station_list.append(j)

# 初始化一个空的 DataFrame，用于存储所有站点的数据
all_data = pd.DataFrame(index=all_hours, columns=['station_id', 'CO_Concentration'])

for station_id in station_list:
    # 筛选特定站点的数据
    station_data = data_df[(data_df['station_id'] == station_id) & (data_df['time'] >= start_time) & (
                data_df['time'] <= end_time)]

    # 重新索引到完整的时间范围，并填充缺失值为 NaN
    station_data = station_data.set_index('time').reindex(all_hours).reset_index()
    station_data.rename(columns={'index': 'time'}, inplace=True)  # 确保时间列名为 'time'
    station_data['station_id'] = station_id

    # 将数据合并到 all_data 中
    all_data = pd.concat([all_data, station_data], ignore_index=True)

# 确保 time 排序
all_data = all_data.sort_values(by=['station_id', 'time'])

# 使用 groupby 按站点分组，并转换为列表
pm25_matrix = all_data.groupby('station_id')['CO_Concentration'].apply(list)

# 转换为 DataFrame
pm25_matrix = pd.DataFrame(pm25_matrix.tolist(), index=pm25_matrix.index)
# pm25_matrix = np.nan_to_num(pm25_matrix)

# 定义目标范围
target_min, target_max = 0.1, 20

# 找到 PM2.5 数据的最小值和最大值（排除 NaN）
orig_min = pm25_matrix.min().min()  # 计算整个 DataFrame 的最小值
orig_max = pm25_matrix.max().max()  # 计算整个 DataFrame 的最大值

# 进行 Min-Max 归一化（只对非空值进行）
pm25_scaled = pm25_matrix.copy()
pm25_scaled = pm25_scaled.applymap(lambda x: target_min + (x - orig_min) /
            (orig_max - orig_min) * (target_max - target_min) if not np.isnan(x) else np.nan)

np.savetxt("CO_data.csv", pm25_scaled, delimiter=",")