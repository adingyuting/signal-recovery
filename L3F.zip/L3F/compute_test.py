import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

def haversine_distance(lat1, lon1, lat2, lon2):
    """
    使用 Haversine 公式计算两点（lat1, lon1）和（lat2, lon2）之间的球面距离（单位：公里）。
    """
    R = 6371.0  # 地球平均半径（公里）
    # 将纬度、经度转换为弧度
    phi1, phi2 = np.radians(lat1), np.radians(lat2)
    delta_phi = np.radians(lat2 - lat1)
    delta_lambda = np.radians(lon2 - lon1)

    # Haversine 公式
    a = (np.sin(delta_phi / 2.0) ** 2 +
         np.cos(phi1) * np.cos(phi2) * np.sin(delta_lambda / 2.0) ** 2)
    c = 2.0 * np.arcsin(np.sqrt(a))
    return R * c

def compute_distance_matrix(coords):
    """
    计算所有站点之间的球面距离矩阵 D (单位：公里)。
    coords: (N, 2) 的数组，其中每行是 (lat, lon)。
    """
    num_nodes = len(coords)
    D = np.zeros((num_nodes, num_nodes), dtype=np.float64)
    for i in range(num_nodes):
        for j in range(num_nodes):
            if i != j:
                lat1, lon1 = coords[i]
                lat2, lon2 = coords[j]
                D[i, j] = haversine_distance(lat1, lon1, lat2, lon2)
    return D

def construct_adjacency_matrix(D, sigma=6.0, k=5):
    """
    根据距离矩阵 D 使用高斯核 + k 近邻计算邻接矩阵 A。
    - sigma: 高斯核参数，控制距离衰减速度
    - k: 每个节点保留最近的 k 个邻居
    A[i, j] = exp(-(D[i,j]^2) / (sigma^2))  (仅保留 k 近邻)
    """
    num_nodes = D.shape[0]
    A = np.zeros((num_nodes, num_nodes), dtype=np.float64)

    for i in range(num_nodes):
        # 对第 i 行的距离排序，取除自身外最近的 k 个邻居
        sorted_indices = np.argsort(D[i, :])
        nearest_indices = sorted_indices[1:k+1]  # 第0个是自身，跳过

        for j in nearest_indices:
            # 高斯核权重
            A[i, j] = np.exp(- (D[i, j] ** 2) / (sigma ** 2))
            # 若需要对称，可再加 A[j, i] = A[i, j]
            A[j, i] = A[i, j]

    return A

def compute_random_walk_laplacian(A):
    """
    计算随机游走拉普拉斯矩阵 L_rw = I - D^{-1} A
    A: 邻接矩阵
    """
    # 度向量：每个节点的度 = ∑ A[i, :]
    degrees = np.sum(A, axis=1)
    # 构造度矩阵 D_mat
    D_mat = np.diag(degrees)

    # 计算 D^{-1}A，需要防止度为 0 的节点（若有）
    # 这里用 np.divide + where 避免除零
    D_inv = np.diag(1.0 / (degrees + 1e-12))  # 防止度为0出现除 0
    DA = D_inv @ A

    # L_rw = I - D^{-1}A
    I = np.eye(A.shape[0])
    L_rw = I - DA
    return L_rw


def plot_adjacency_values(D, sigma_values):
    plt.figure(figsize=(8, 6))
    for sigma in sigma_values:
        A_test = np.exp(- (D ** 2) / (sigma ** 2))
        A_test[A_test < 1e-4] = 0  # 设定小权重为 0，提高可视化效果
        values = A_test.flatten()
        plt.hist(values[values > 0], bins=50, alpha=0.5, label=f"sigma={sigma}")

    plt.xlabel("Edge Weight (Adjacency Value)")
    plt.ylabel("Frequency")
    plt.title("Gaussian Kernel Adjacency Matrix Distribution")
    plt.legend()
    plt.show()
def main():
    # 1. 读取 Excel 文件
    file_path = "beijinng_location.xlsx"  # 请修改为实际文件路径
    station_df = pd.read_excel(file_path)

    # station_df 中假设：
    # C 列为 '经度'，D 列为 '纬度'
    # 若与实际文件不符，请调整下面的列名
    # 提取 (lat, lon) 格式的坐标
    coords = station_df[['纬度', '经度']].values  # (N, 2) -> (lat, lon)

    # 2. 计算距离矩阵 D
    D = compute_distance_matrix(coords)

    # 3. 构造邻接矩阵 A（高斯核 + k 近邻）
    sigma = 6.0
    k = 7
    sigma_values = [35]
    plot_adjacency_values(D, sigma_values)
    A = construct_adjacency_matrix(D, sigma=sigma, k=k)
    degrees = np.sum(A > 0.1, axis=1)  # 计算度数
    plt.hist(degrees, bins=20, alpha=0.7, color='b', edgecolor='k')
    plt.xlabel("Node Degree")
    plt.ylabel("Frequency")
    plt.title("Degree Distribution")
    plt.show()

    # 4. 计算随机游走拉普拉斯矩阵 L_rw
    L_rw = compute_random_walk_laplacian(A)

    # 5. 输出结果
    print("邻接矩阵 A:")
    print(A)
    print("\n随机游走拉普拉斯矩阵 L_rw:")
    print(L_rw)

    # 如果需要保存
    np.savetxt("adjacency_matrix.csv", A, delimiter=",")
    np.savetxt("L_rw.csv", L_rw, delimiter=",")
    print("!!")

if __name__ == "__main__":
    main()
