import numpy as np
import math
import datetime
import  pandas as pd
from sklearn.preprocessing import StandardScaler
class LSF():
    def __init__(self, Parameters, shape, R):
        self.Parameters = Parameters
        I, J= shape
        # 初始化 S, D, T
        self.P= np.random.rand(I, R)
        self.Q = np.random.rand(J, R)
        # self.T = np.random.rand(K, R)
        # 记录最佳的 S, D, T
        self.best_Q = np.zeros([I, R])
        self.best_P = np.zeros([J, R])
        # self.best_T = np.zeros([K, R])
        self.best_tol = 0
        self.best_loss = float('inf')
        self.best_n = float('inf')
        # 假设空间和时间拉普拉斯矩阵 L_space 和 L_time
        self.L_space = np.random.rand(I, I)  # 空间流形矩阵
        self.L_time = np.random.rand(J, J)  # 时间流形矩阵

    def train(self, train_indices, valid_indices, num_epochs=100, epsilon=0.01):
        tol = float('inf')
        last_loss = float('inf')
        n = 1
        conv_count = 0  # 计算连续几个epoch没有显著改进
        while n < num_epochs:
            # 更新P和Q
            self.P, self.Q = self.update(self.P, self.Q, self.Parameters, train_indices)

            # 在第一轮进行验证，记录损失
            if n == 1:
                rmse, mae = self.metrics(self.P, self.Q, valid_indices)
                last_loss = rmse
                self.best_loss = last_loss
                self.best_n = n
                print(f'验证集: 迭代轮数:{n}, 损失:{last_loss}')
                self._save_best()

            # 从第二轮开始继续训练，检查收敛情况
            else:
                rmse, mae = self.metrics(self.P, self.Q, valid_indices)
                loss = rmse
                tol = last_loss - loss  # 当前损失与上一次损失的差值
                print(f'验证集: 迭代轮数:{n}, 损失:{loss}, tol:{tol}')

                if tol > epsilon:  # 如果损失仍在改善
                    conv_count = 0  # 重置收敛计数器
                    # 如果当前损失小于历史最优损失，更新最佳损失
                    if loss < self.best_loss:
                        self.best_loss = loss
                        self.best_n = n
                        self.best_tol = tol
                        self._save_best()
                else:
                    conv_count += 1  # 收敛计数器加1

                    # 如果连续5次没有明显改进，则停止训练
                    if conv_count >= 5:
                        print(f'早停机制触发：连续5次没有改进，停止训练！')
                        break

            last_loss = loss
            n += 1

    def L2update(self,Parameters,err,Pi,Qj):
        eta =Parameters[0]
        beta_L2 = Parameters[1]
        gra_P = -eta * (beta_L2 * (-err * Qj))
        gra_Q = -eta * (beta_L2 * (-err * Pi))
        return [gra_P,gra_Q]

    def L1update(self,Parameters,err,Pi,Qj):
        eta =Parameters[0]
        beta_L1 = Parameters[2]
        sign_err = np.sign(err)  # 误差的符号函数
        # 计算梯度
        gra_P = -eta * beta_L1 * sign_err * Qj
        gra_Q = -eta * beta_L1 * sign_err * Pi
        return [gra_P,gra_Q]

    def spatio_update(self,Parameters, Pi, Qj, L):
        """空间流形约束梯度更新"""
        eta = Parameters[0]
        beta_spatio = Parameters[3]
        gra_P = -2 * eta * beta_spatio * (L @(Pi@(Qj.T)))@ Pi  # L是空间拉普拉斯矩阵
        gra_Q = np.zeros_like(Qj)  # 假设空间流形约束不直接作用于Q
        return [gra_P, gra_Q]

    def temporal_update(self,Parameters, Pi, Qj, D):
        """时间流形约束梯度更新"""
        eta = Parameters[0]
        beta_temporal = Parameters[4]
        gra_Q = -2 * eta * beta_temporal * D @ Qj  # L是时间拉普拉斯矩阵
        gra_P = np.zeros_like(Pi)  # 假设时间流形约束不直接作用于P
        return [gra_P, gra_Q]

    def update(self,P, Q, Parameters, train_indices):
        for [i, j, Y] in train_indices:
            # k = int(k)
            i = int(i)
            j = int(j)
            Y_hat = self.get_Y_hat(P[i], Q[j])
            err = Y-Y_hat
            # 更新P和Q
            grad_P = (self.L1update(Parameters, err, P[i], Q[j])[0] +
                      self.L2update(Parameters, err, P[i], Q[j])[0]
                      # self.spatio_update(Parameters, P[i], Q[j], self.L_space[i:])[0] +
                      # self.temporal_update(Parameters, P[i], Q[j], self.L_time[j])[0]
                      )
            grad_Q = (self.L1update(Parameters, err, P[i], Q[j])[1] +
                      self.L2update(Parameters, err, P[i], Q[j])[1]
                      # self.spatio_update(Parameters, P[i], Q[j], self.L_space[i])[1] +
                      # self.temporal_update(Parameters, P[i], Q[j], self.L_time[j])[1]
                      )
            P[i] += grad_P
            Q[j] += grad_Q

        return [P,Q]

    # 获得y_hat
    def get_Y_hat(self,P_i, Q_j):
        return np.sum(P_i * Q_j)

    def metrics(self,S, D, T, indices):
        """
        传入两个张量和需要测试的元素下标
        """
        RMSE = 0
        MSE = 0
        test_num = len(indices)
        for [k, i, j, Y] in indices:
            k = int(k)
            i = int(i)
            j = int(j)
            Y_hat = np.sum(S[i] * D[j] * T[k])
            RMSE = RMSE + (Y - Y_hat) ** 2
            MSE = MSE + abs(Y - Y_hat)
        RMSE = math.sqrt(RMSE / test_num)
        MSE = MSE / test_num
        return [RMSE, MSE]

    def _save_best(self):
        self.best_P = self.P.copy()
        self.best_Q = self.Q.copy()



def getData():
    # 读取数据
    train = pd.read_csv(r'D:\学术工作\pythonProject\L3F\train.txt', delimiter='::', header=None)
    test = pd.read_csv(r'D:\学术工作\pythonProject\L3F\test.txt', delimiter='::', header=None)

    # 设置列名
    train.columns = ['row', 'col', 'value']
    test.columns = ['row', 'col', 'value']

    # 获取最大行列索引以确定data的维度
    max_row = max(train['row'].max(), test['row'].max()) + 1  # +1 以确保索引覆盖所有行
    max_col = max(train['col'].max(), test['col'].max()) + 1  # +1 以确保索引覆盖所有列

    # 创建空的 DataFrame
    data = pd.DataFrame(index=range(max_row), columns=[f'Col_{i}' for i in range(max_col)])

    # 填充train数据
    for _, row in train.iterrows():
        data.at[int(row['row']), f'Col_{int(row["col"])}'] = row['value']

        # 填充test数据
    for _, row in test.iterrows():
        data.at[int(row['row']), f'Col_{int(row["col"])}'] = row['value']


    # 数据标准化
    scaler1 = StandardScaler()
    data = scaler1.fit_transform(data)


    i, j = data.shape

    # 创建k, i, j的索引数组,形状为(k, i, j，3) 3列的值分别对应 k,i,j
    indices = np.indices((i, j)).reshape(2, -1).T

    # 张量展平
    values = data.flatten()

    # 移除values中的NaN值
    indices = indices[~np.isnan(values)]  # 使用逻辑索引来移除NaN值
    values = values[~np.isnan(values)]  # 同样移除对应的NaN值

    # 堆叠为 k ,i, j , value 这样的数组
    result_array = np.column_stack((indices, values))
    # 检查result_array中是否包含NaN值
    if np.isnan(result_array).any():
        print("警告：result_array中存在NaN值。")
        # 如果需要，可以移除包含NaN的行
        result_array = result_array[~np.isnan(result_array).any(axis=1)]
        print("已移除包含NaN的行。")
    else:
        print("result_array中没有NaN值。")
    # Manual normalization
    min_val = np.min(result_array[:, 2])  # Get min value of the 'values'
    max_val = np.max(result_array[:, 2])  # Get max value of the 'values'

    # Normalize values to [0, 1]
    result_array[:, 2] = (result_array[:, 2] - min_val) / (max_val - min_val)

    # Shuffle the array
    np.random.shuffle(result_array)

    # Split into training, validation, and testing sets
    total_rows = result_array.shape[0]
    train_size = int(0.6 * total_rows)
    val_size = int(0.2 * total_rows)

    # Split into sets
    train_set = result_array[:train_size, :]
    val_set = result_array[train_size:train_size + val_size, :]
    test_set = result_array[train_size + val_size:, :]
    return train_set, val_set, test_set, data.shape


# 学习率
eta = 0.001
beta_L2=0.0001
beta_L1=0.0001
beta_spatio=0
beta_temporal=0

# 隐藏特征维度
R = 20
# 最大迭代次数
max_iter_num = 100
# 收敛临界值
epsilon = 1e-6
train_set, val_set, test_set, shape = getData()

model = LSF([eta, beta_L2, beta_L1, beta_spatio, beta_temporal], shape, R)
# 参数分别为:训练集,验证集 ,最大迭代次数,收敛临界值
model.train(train_set, val_set, max_iter_num, epsilon)

# 获取训练过程中的loss,迭代次数,和tol
loss, n, tol = model.get_current_info()

# 传入测试集
rmse, mae = model.metrics(test_set)

print(f'rmse:{rmse},mae:{mae},loss:{loss},迭代次数:{n},tol:{tol}')