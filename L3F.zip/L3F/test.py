import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error
import os


# ============================
# 数据加载模块
# ============================
def load_and_process_data(data_folder):
    """
    从指定文件夹中读取 train.txt 与 test.txt 文件，
    构建完整数据矩阵、缺失值掩码，并对非缺失值进行标准化。
    """
    # 构建文件路径
    train_file = os.path.join(data_folder, "train.txt")
    test_file = os.path.join(data_folder, "test.txt")

    # 读取数据（注意 delimiter 中使用 engine='python' 以支持正则表达式分隔符）
    train = pd.read_csv(train_file, delimiter='::', header=None, engine='python')
    test = pd.read_csv(test_file, delimiter='::', header=None, engine='python')

    # 设置列名
    train.columns = ['row', 'col', 'value']
    test.columns = ['row', 'col', 'value']

    # 获取矩阵尺寸（+1 以覆盖所有索引）
    max_row = int(max(train['row'].max(), test['row'].max()))
    max_col = int(max(train['col'].max(), test['col'].max()))

    # 初始化完整矩阵，缺失值用 NaN 表示
    data = pd.DataFrame(np.nan, index=range(max_row), columns=[f'Col_{i}' for i in range(max_col)])

    # 填充 train 数据
    for _, row in train.iterrows():
        data.at[int(row['row']-1), f'Col_{int(row["col"]-1)}'] = row['value']
    # 填充 test 数据
    for _, row in test.iterrows():
        data.at[int(row['row']-1), f'Col_{int(row["col"]-1)}'] = row['value']

    # 转换为 numpy 数组
    data_array = data.values.astype(np.float32)

    # 构造缺失值掩码：已知值为1，缺失值为0
    mask = ~np.isnan(data_array)
    mask = mask.astype(np.float32)

    # 对非缺失值进行标准化
    known_values = data_array[~np.isnan(data_array)].reshape(-1, 1)
    scaler = StandardScaler()
    scaler.fit(known_values)

    data_normalized = data_array.copy()
    normalized_values = scaler.transform(data_array[~np.isnan(data_array)].reshape(-1, 1)).flatten()
    data_normalized[~np.isnan(data_normalized)] = normalized_values

    # 将缺失值填充为 0（训练时通过 mask 排除）
    data_normalized[np.isnan(data_normalized)] = 0

    num_sites, num_time_points = data_normalized.shape

    return data_normalized, mask, num_sites, num_time_points, scaler


def split_data_simple(data, train_ratio=0.8):
    """
    按比例划分训练集和测试集，生成对应的掩码矩阵。
    仅对非缺失值进行划分。
    """
    known_indices = np.argwhere(~np.isnan(data))
    np.random.shuffle(known_indices)

    num_train = int(len(known_indices) * train_ratio)
    train_indices = known_indices[:num_train]
    test_indices = known_indices[num_train:]

    train_mask = np.zeros_like(data, dtype=np.float32)
    test_mask = np.zeros_like(data, dtype=np.float32)

    for i, j in train_indices:
        train_mask[i, j] = 1.0
    for i, j in test_indices:
        test_mask[i, j] = 1.0

    return train_mask, test_mask


# ============================
# 矩阵加载模块
# ============================
def load_L_matrix_from_file(file_path):
    """
    读取 L 矩阵（站点数 x 站点数）
    """
    L = pd.read_csv(file_path, delimiter=',', header=None).values
    return torch.tensor(L, dtype=torch.float32)


def generate_random_fourier_matrix(num_time_points, num_features=1, gamma=1.0):
    """
    生成时间正则矩阵 D（num_time_points x num_time_points）
    """
    omega = np.random.normal(0, gamma, size=(num_features, 1))
    b = np.random.uniform(0, 2 * np.pi, size=(num_features,))

    time_points = np.arange(num_time_points).reshape(-1, 1)
    random_fourier_features = np.sqrt(2 / num_features) * np.cos(omega @ time_points.T + b[:, None])

    D = random_fourier_features.T @ random_fourier_features
    D = (D + D.T) / 2  # 保证矩阵对称

    return torch.tensor(D, dtype=torch.float32)


# ============================
# 模型定义模块
# ============================
class MatrixFactorizationModel(nn.Module):
    def __init__(self, num_sites, num_time_points, rank):
        super(MatrixFactorizationModel, self).__init__()
        self.S = nn.Parameter(torch.rand(num_sites, rank))
        self.U = nn.Parameter(torch.rand(num_time_points, rank))

    def forward(self):
        return torch.matmul(self.S, self.U.t())


# ============================
# 损失函数模块
# ============================
def compute_loss_with_mask(model, data, mask, L, D, params):
    reconstruction = model()
    # 仅对已知部分计算误差
    pred_values = reconstruction * torch.tensor(mask, dtype=torch.float32)
    true_values = torch.tensor(data, dtype=torch.float32) * torch.tensor(mask, dtype=torch.float32)

    diff = true_values - pred_values

    delta = 0.86
    huber_loss = params["alpha2"] * F.huber_loss(diff, torch.zeros_like(diff), delta=delta, reduction='sum')
    l1_loss = params["alpha1"] * torch.norm(diff, p=1)
    tikhonov_reg = params["lambda_reg"] * (torch.norm(model.S, p='fro') + torch.norm(model.U, p='fro'))
    spatial_reg = params["z1"] * torch.trace(torch.matmul(model.S.t(), torch.matmul(L, model.S)))
    temporal_reg = params["z2"] * torch.trace(torch.matmul(model.U.t(), torch.matmul(D, model.U)))

    total_loss = l1_loss + huber_loss + tikhonov_reg + spatial_reg + temporal_reg
    return total_loss


# ============================
# 训练模块
# ============================
def train_model(model, train_data, test_data, train_mask, test_mask, L, D, params, num_epochs, lr, scaler, patience=50):
    best_rmse = float("inf")
    epochs_without_improvement = 0
    best_model_state = None

    for epoch in range(num_epochs):
        model.train()
        model.zero_grad()

        loss = compute_loss_with_mask(model, train_data, train_mask, L, D, params)
        loss.backward()

        # 手动更新参数
        with torch.no_grad():
            for param in model.parameters():
                param -= lr * param.grad

        # 在测试集上评估 RMSE（反标准化后计算）
        model.eval()
        with torch.no_grad():
            reconstruction = model().detach().numpy()
            true_test = test_data[test_mask == 1]
            pred_test = reconstruction[test_mask == 1]

            true_test_inv = scaler.inverse_transform(true_test.reshape(-1, 1)).flatten()
            pred_test_inv = scaler.inverse_transform(pred_test.reshape(-1, 1)).flatten()

            mse = mean_squared_error(true_test_inv, pred_test_inv)
            rmse = np.sqrt(mse)

        print(f"Epoch {epoch + 1}/{num_epochs}, Loss: {loss.item():.4f}, RMSE: {rmse:.4f}")

        if rmse < best_rmse:
            best_rmse = rmse
            epochs_without_improvement = 0
            best_model_state = model.state_dict()
        else:
            epochs_without_improvement += 1

        if epochs_without_improvement >= patience:
            print(f"Early stopping triggered at epoch {epoch + 1}")
            break

    if best_model_state is not None:
        model.load_state_dict(best_model_state)
        print(f"Restored model to the best state with RMSE: {best_rmse:.4f}")


# ============================
# 主程序
# ============================
if __name__ == "__main__":
    # 指定数据所在文件夹，确保该文件夹包含 train.txt 和 test.txt 文件
    data_folder = r"."
    L_path = r"./seadata/L_rw_sea.csv"

    data, mask, num_sites, num_time_points, scaler = load_and_process_data(data_folder)
    train_mask, test_mask = split_data_simple(data, train_ratio=0.8)
    L = load_L_matrix_from_file(L_path)
    D = generate_random_fourier_matrix(num_time_points)

    rank = 20
    model = MatrixFactorizationModel(num_sites, num_time_points, rank)
    params = {"alpha1": 0, "alpha2": 1, "lambda_reg": 0.0002, "z1": 0.00, "z2": 0}
    num_epochs = 5000
    lr = 0.001

    # 构造训练和测试数据（仅保留已知值，其他部分为 0）
    train_data = data * train_mask
    test_data = data * test_mask

    train_model(model, train_data, test_data, train_mask, test_mask, L, D, params, num_epochs, lr, scaler, patience=20)
