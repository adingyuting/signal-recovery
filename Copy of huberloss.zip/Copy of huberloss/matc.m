function matrix=matc(matrix1,matrix2)
    
    if matrix2(1,1)
        matrix=matrix1*matrix2; 
    else
        [N] = size(matrix2);
        matrix2=matrix2(2:N,:);
        matrix=matrix1*matrix2;
    end
   
        
end