

public class RTuple {
	
	public int iUserID = 0;
	
	public int iItemID = 0;
	
	public double dRating = 0;

	public double dError = 0;

	public double dRatingHat = 0;

	public double dWeight = 0;
	
	public boolean bFailed = false;
	
	public double DuQiDot = 0;
	
	public double PuDiDot = 0;
	
	
}
