
import sun.misc.Contended;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.StringTokenizer;



import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.StringTokenizer;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.StringTokenizer;
import java.util.concurrent.CountDownLatch;


public abstract class Common_Function
{
	

	
	
	public static double sampliRate=0;
	public int err_type = 1;// 1:RMSE;other:MAE.
	public double minInnerLoopCount = 0;

	public double cacheInnerLoopCount = 0;

	public double minTotalTime = 0;

	public double cacheTotalTime = 0;

	public static boolean flag_B = true;

	public static boolean flag_C = true;

	public static double min_Error_RMSE = 1e10;
	public static double min_Error_MAE = 1e10;

	public double previous_Error = 1e10;

	public double max_Error = 0;

	public int min_Round = 0;

	public static int con_n = 300;

	public static int delayCount = 10;

	// 鐞涘瞼澹掑锟�
	public static int B_Count = 1;

	//閻€劋浜掗崚婵嗩潗閸栨渾閻ㄥ嫬鐔�閺佹壆绮嶉敍灞肩箽鐠囦竻_count娑撳﹤宕岄弮璁圭礉娑撳秴鎮揷ount鐎电懓绨查惃鍕倱娑擄拷娑擃亜鐤勬担鎾舵畱閸滃瞼娴夌粵锟�
	public static double[] B_Base;

	public double[][] B;

	public static double[][] min_B, B_cache, B_delta;
	@Contended
	public  static  double[][] P;

	public static double[][] min_P, P_cache, P_delta;

	// 閸掓澹掑锟�
	public static int C_Count = 1;

	//閻€劋浜掗崚婵嗩潗閸栨渿閻ㄥ嫬鐔�閺佹壆绮嶉敍灞肩箽鐠囦竼_count娑撳﹤宕岄弮璁圭礉娑撳秴鎮揷ount鐎电懓绨查惃鍕倱娑擄拷娑擃亜鐤勬担鎾舵畱閸滃瞼娴夌粵锟�
	public static double[]  C_Base;
	
	public double[][] C;

	public static double[][] min_C, C_cache, C_delta;
	@Contended
	public  static  double[][] Q;

	public static double[][] min_Q, Q_cache, Q_delta;

	// 娑擄拷闂冭埖顫惔锟�
	public static double[][] B_gradient, C_gradient, P_gradient, Q_gradient;

	// 閻€劍娼垫潻娑滎攽鐠侊紕鐣婚崗杈睙濮婎垰瀹抽惃鍕处鐎涙鐓╅梼锟�
	public static double[][] B_r, B_p, B_r_prime, C_r, C_p, C_r_prime, P_r,
			P_p, P_r_prime, Q_r, Q_r_prime, Q_p;

	// 閻€劍娼电拋鏉跨秿Hessian閻晠妯�娑撳骸鎮滈柌蹇庣缁夘垳娈戠紓鎾崇摠閻晠妯�
	public static double[][] B_hp, C_hp, P_hp, Q_hp;

	// 鐠佹澘缍嶉悽銊﹀煕閸滃矂銆嶉惄鐣哸ting閺佷即鍣洪惃鍕殶缂侊拷
	public static double[] user_Rating_count, item_Rating_count;

	// 閻楃懓绶涚紒瀛樻殶
	public static int featureDimension = 20;

	// 鐠侇厾绮屾潪顔芥殶
	public static int trainingRound = 1000;

	// 閻楃懓绶涢崚婵嗩潗閸婏拷
	public static double init_Max = 0.004;

	public static double init_Scale = 0.004;

	public static int mapping_Scale = 1000;

	// 閹貉冨煑閸欏倹鏆�
	public static double eta = 0.0001;

	public static double lambda1 = 0.01;
	public static double lambda2 = 0.01;
	public static double gama = 0.01;

	public static double tau = 0.001;

	public static double epsilon = 0.001;

	public static ArrayList<RTuple> trainData = null;
	public static ArrayList<RTuple> trainData_temp = null;

	public static ArrayList<RTuple> testData = null;

	public static int item_MaxID = 0, user_MaxID = 0;

	public static double noise_ratio = 0;
	
	public static double rating_Max = 0, rating_Min = 1e10;
	public static double noise_value = 0;
	public static double times_magnification = 1;
	
	
	public abstract void train() throws IOException, InterruptedException;

	public Common_Function() throws NumberFormatException, IOException
	{
		initInstanceFeatures();
	}

	public static void initBiasSettings(boolean ifB, boolean ifC, int B_C,int C_C)
	{
		flag_B = ifB;
		flag_C = ifC;
		B_Count = B_C;
		C_Count = C_C;
		
		B_cache = new double[user_MaxID + 1][B_Count];
		min_B = new double[user_MaxID + 1][B_Count];

		C_cache = new double[item_MaxID + 1][C_Count];
		min_C = new double[item_MaxID + 1][C_Count];
		
		System.gc();

		if(B_Count!=0)
		{
			for (int i = 1; i <= user_MaxID; i++) 
			{
				double tempUB = B_Base[i]/B_Count;
				for (int j = 0; j < B_Count; j++) 
				{
					B_cache[i][j] = tempUB;
					min_B[i][j] = B_cache[i][j];
				}
			}
		}

		if(C_Count!=0)
		{
			for (int i = 1; i <= item_MaxID; i++) 
			{
				double tempIB = C_Base[i]/C_Count;
				for (int j = 0; j < C_Count; j++) 
				{
					C_cache[i][j] = tempIB;
					min_C[i][j] = C_cache[i][j];
				}
			}
		}
	}

	public static void initiStaticArrays() 
	{
		// 閸旓拷1閺勵垯璐熸禍鍡楁躬鎼村繐褰挎稉濠佺瑢ID娣囨繃瀵旀稉锟介懛锟�
		user_Rating_count = new double[user_MaxID + 1];
		item_Rating_count = new double[item_MaxID + 1];

		P_cache = new double[user_MaxID + 1][featureDimension];
		Q_cache = new double[item_MaxID + 1][featureDimension];

		//min_P = new double[user_MaxID + 1][featureDimension];
		//min_Q = new double[item_MaxID + 1][featureDimension];

		B_Base = new double[user_MaxID + 1];
		C_Base = new double[item_MaxID + 1];

		// 閸掓繂顫愰崠鏍瀵颁胶鐓╅梼锟�,闁插洨鏁ら梾蹇旀簚閸婏拷,娴犲氦锟藉苯鑸伴幋鎰娑撶嫷闂冨爼锟借壈绻�
		Random random = new Random(System.currentTimeMillis());
		for (int i = 1; i <= user_MaxID; i++)
		{
			user_Rating_count[i] = 0;
			int tempBB = random.nextInt(mapping_Scale);
			
			
//			閸愬啿鐣鹃崝鐘辩瑝閸旂嚱ias閻ㄥ嫭鍎忛崘锟�
//			B_Base[i] = init_Max - init_Scale * tempBB / mapping_Scale;
			B_Base[i] = 0;//閺冪嚱ias閻ㄥ嫭鍎忛崘纰夌礉閸掓瑨顔曠純顔昏礋0
			
						
			for (int j = 0; j < featureDimension; j++) 
			{
				int temp = random.nextInt(mapping_Scale);
				P_cache[i][j] = init_Max - init_Scale * temp / mapping_Scale;
				//min_P[i][j] = P_cache[i][j];
			}
		}
		for (int i = 1; i <= item_MaxID; i++)
		{
			item_Rating_count[i] = 0;
			int tempCB = random.nextInt(mapping_Scale);
			
			
//			閸愬啿鐣鹃崝鐘辩瑝閸旂嚱ias閻ㄥ嫭鍎忛崘锟�
//			C_Base[i] = init_Max - init_Scale * tempCB / mapping_Scale;
			C_Base[i] = 0;//閺冪嚱ias閻ㄥ嫭鍎忛崘纰夌礉閸掓瑨顔曠純顔昏礋0
			
			
			
			for (int j = 0; j < featureDimension; j++)
			{
				int temp = random.nextInt(mapping_Scale);
				Q_cache[i][j] = init_Max - init_Scale * temp / mapping_Scale;
				//min_Q[i][j] = Q_cache[i][j];

			}
		}

		for (RTuple tempRating : trainData) 
		{
			user_Rating_count[tempRating.iUserID] += 1;
			item_Rating_count[tempRating.iItemID] += 1;
		}
	}


	public void initInstanceFeatures() {
		B = new double[user_MaxID + 1][B_Count];
		C = new double[item_MaxID + 1][C_Count];
		P = new double[user_MaxID + 1][featureDimension];
		Q = new double[item_MaxID + 1][featureDimension];
		for (int i = 1; i <= user_MaxID; i++) {
			for (int j = 0; j < B_Count; j++) {
				B[i][j] = B_cache[i][j];
			}
			for (int j = 0; j < featureDimension; j++) {
				P[i][j] = P_cache[i][j];
			}
		}
		for (int i = 1; i <= item_MaxID; i++) {
			for (int j = 0; j < C_Count; j++) {
				C[i][j] = C_cache[i][j];
			}
			for (int j = 0; j < featureDimension; j++) {
				Q[i][j] = Q_cache[i][j];
			}
		}
	}

	public void cacheMinFeatures()
	{
		for (int i = 1; i <= user_MaxID; i++) 
		{
			for (int j = 0; j < B_Count; j++) 
			{
				min_B[i][j] = min_B[i][j];
			}
			for (int j = 0; j < featureDimension; j++)
			{
				min_P[i][j] = P[i][j];
			}
		}
		for (int i = 1; i <= item_MaxID; i++) 
		{
			for (int j = 0; j < C_Count; j++)
			{
				min_C[i][j] = C[i][j];
			}
			for (int j = 0; j < featureDimension; j++)
			{
				min_Q[i][j] = Q[i][j];
			}
		}
	}

	public static void initializeRatings(String trainFileName,String testFileName, String separator)
	             throws NumberFormatException, IOException 
	{
		// 閸旂姴鍙嗙�电瓓atingMap閻ㄥ嫬鍨垫慨瀣
		initTrainData(trainFileName, separator);
		initTestData(testFileName, separator);
	}

	public static void initTrainData(String fileName, String separator)
			throws NumberFormatException, IOException {
		trainData_temp = new ArrayList<RTuple>();
		trainData = new ArrayList<RTuple>();
		
		File personSource = new File(fileName);
		BufferedReader in = new BufferedReader(new FileReader(personSource));

		String tempVoting;
		int Num_trainData=0;
		while (((tempVoting = in.readLine()) != null)) {
			StringTokenizer st = new StringTokenizer(tempVoting, separator);
			String personID = null;
			if (st.hasMoreTokens())
				personID = st.nextToken();
			String movieID = null;
			if (st.hasMoreTokens())
				movieID = st.nextToken();
			String personRating = null;
			if (st.hasMoreTokens())
				personRating = st.nextToken();
			int iUserID = Integer.valueOf(personID);
			int iItemID = Integer.valueOf(movieID);

			// 鐠佹澘缍嶆稉瀣付婢堆呮畱itemid閸滃瘈serid閿涙稑娲滄稉绡縯emid閸滃瘈serid閺勵垵绻涚紒顓犳畱閿涘本澧嶆禒銉︽付婢堆呮畱itemid閸滃瘈serid娑旂喍鍞悰銊ょ啊閸氬嫯鍤滈惃鍕殶閻╋拷
			user_MaxID = (user_MaxID > iUserID) ? user_MaxID : iUserID;
			item_MaxID = (item_MaxID > iItemID) ? item_MaxID : iItemID;
			double dRating = Double.valueOf(personRating);

			RTuple temp = new RTuple();
			temp.iUserID = iUserID;
			temp.iItemID = iItemID;
			temp.dRating = dRating*times_magnification;
			trainData_temp.add(temp);
			Num_trainData+=1;
			rating_Max=(rating_Max > temp.dRating) ? rating_Max : temp.dRating;
			rating_Min=(rating_Min < temp.dRating) ? rating_Min : temp.dRating;
		}
	
//		System.out.println(rating_Max+"  "+rating_Min); 
		
//		int[] Ru = new int[user_MaxID+1];           /// 莽鈥澛λ喡穟忙鈥扳�溍ニ嗏�犆♀�灻┞÷姑р�郝︹�⒙�
//		double[] bu = new double[user_MaxID+1];
//		double sumRating = 0; 
//		for(RTuple tempRating : trainData_temp)
//		{
//			sumRating += tempRating.dRating;                      
//		     Ru[tempRating.iUserID] ++;
//		     bu[tempRating.iUserID] += tempRating.dRating;	   
//		}	
//		double outlier_threhold=(rating_Max+rating_Min)/2;
//		double[] Bias_value = new double[user_MaxID+1];
//		
//		for(int i=1; i<=user_MaxID; i++)
//		{
//			Bias_value[i]=bu[i]/Ru[i];
//		}	
////		System.out.println(outlier_threhold);
		
	
		
		//adding noise ratings
		int []UserList = new int[Num_trainData+1];
		int []ItemList = new int[Num_trainData+1];
		double []RatingList = new double[Num_trainData+1];
        int  input_i=1; 
		 for(RTuple tempRating : trainData_temp)
 		{ 
			 UserList[input_i]=tempRating.iUserID;
			 ItemList[input_i]=tempRating.iItemID;
			 RatingList[input_i]=tempRating.dRating;
			 input_i++;
 		}	
	
	     int noise_number=(int)(Math.round(noise_ratio*Num_trainData));
	    
	
		 for (int i = 1; i <= Num_trainData-1; i++)
		 {
				RTuple temp = new RTuple();
				temp.iUserID = UserList[i];
				temp.iItemID = ItemList[i];
				temp.dRating = RatingList[i];
				trainData.add(temp);
				
			 double difference=ItemList[i+1]-ItemList[i];
			 if (difference>=2&&noise_number>0)
			 {
				 int RandomInt = (int)(Math.round(Math.random()*difference)); //0-100浠ュ唴鐨勯殢鏈烘暟锛岀敤Matn.random()鏂瑰紡 
				 RandomInt=ItemList[i]+RandomInt;
				 if (RandomInt==ItemList[i])RandomInt=RandomInt+1;
				 if (RandomInt==ItemList[i+1])RandomInt=RandomInt-1;
				 
				    RTuple temp1 = new RTuple();
					temp1.iUserID = UserList[i];
					temp1.iItemID = RandomInt;
//					temp1.dRating = noise_value;//noise_value
					
					if ((i%2)==1)temp1.dRating = rating_Min;//noise_value
					
//					if (Bias_value[UserList[i]]>=outlier_threhold)temp1.dRating =rating_Min ;//noise_value
					else temp1.dRating = rating_Max;//noise_value
					
					trainData.add(temp1);
					noise_number=noise_number-1;
//					 System.out.println(temp1.dRating); 
			  }
	
		 }
	   
		 
		 ////again to adding the noise if it is not reach to the noise_number
	     while (noise_number!=0){
		 for (int i = 1; i <= Num_trainData-1; i++)
		 {
				
			 double difference=ItemList[i+1]-ItemList[i];
			 if (difference>=2&&noise_number>0)
			 {
				 int RandomInt = (int)(Math.round(Math.random()*difference)); //0-100浠ュ唴鐨勯殢鏈烘暟锛岀敤Matn.random()鏂瑰紡 
				 RandomInt=ItemList[i]+RandomInt;
				 if (RandomInt==ItemList[i])RandomInt=RandomInt+1;
				 if (RandomInt==ItemList[i+1])RandomInt=RandomInt-1;
				 
				    RTuple temp1 = new RTuple();
					temp1.iUserID = UserList[i];
					temp1.iItemID = RandomInt;
					if ((i%2)==1)temp1.dRating = rating_Min;//noise_value

//					if (Bias_value[UserList[i]]>=outlier_threhold)temp1.dRating =rating_Min ;//noise_value
					else temp1.dRating = rating_Max;//noise_value
					trainData.add(temp1);
					noise_number=noise_number-1;
		       }
	
		 }
	     }
	 ////again to adding the noise if it is not reach to the noise_number 
	     
	        
		 // adding the last one of the noise.
			RTuple temp = new RTuple();
			temp.iUserID = UserList[Num_trainData];
			temp.iItemID = ItemList[Num_trainData];
			temp.dRating = RatingList[Num_trainData];
			trainData.add(temp);
				
				//adding noise ratings
				
			
		
				
	in.close();

				
	}

	public static void initTestData(String fileName, String separator)
			throws NumberFormatException, IOException {
		testData = new ArrayList<RTuple>();
		File personSource = new File(fileName);
		BufferedReader in = new BufferedReader(new FileReader(personSource));

		String tempVoting;
		while (((tempVoting = in.readLine()) != null)) {
			StringTokenizer st = new StringTokenizer(tempVoting, separator);
			String personID = null;
			if (st.hasMoreTokens())
				personID = st.nextToken();
			String movieID = null;
			if (st.hasMoreTokens())
				movieID = st.nextToken();
			String personRating = null;
			if (st.hasMoreTokens())
				personRating = st.nextToken();
			int iUserID = Integer.valueOf(personID);
			int iItemID = Integer.valueOf(movieID);

			// 鐠佹澘缍嶆稉瀣付婢堆呮畱itemid閸滃瘈serid閿涙稑娲滄稉绡縯emid閸滃瘈serid閺勵垵绻涚紒顓犳畱閿涘本澧嶆禒銉︽付婢堆呮畱itemid閸滃瘈serid娑旂喍鍞悰銊ょ啊閸氬嫯鍤滈惃鍕殶閻╋拷
			user_MaxID = (user_MaxID > iUserID) ? user_MaxID : iUserID;
			item_MaxID = (item_MaxID > iItemID) ? item_MaxID : iItemID;
		  
			
			
			double dRating = Double.valueOf(personRating);

			RTuple temp = new RTuple();
			temp.iUserID = iUserID;
			temp.iItemID = iItemID;
			temp.dRating = dRating*times_magnification;
			testData.add(temp);
			
			rating_Max=(rating_Max > temp.dRating) ? rating_Max : temp.dRating;
			rating_Min=(rating_Min < temp.dRating) ? rating_Min : temp.dRating;
			
			
		}
//	    System.out.println(item_MaxID);//output the maxID Number of User 
//	      System.out.println(user_MaxID);//output the maxID Number of User 
		in.close();
	}

	// 閸氭垿鍣洪悙閫涚閸戣姤鏆�
	public static double dotMultiply(double[] x, double[] y) {
		double sum = 0;
		for (int i = 0; i < x.length; i++) {
			sum += x[i] * y[i];
		}
		return sum;
	}

	// 閸氭垿鍣洪崝锟�
	
	public static void VectorDivideVector(double[] first, double[] second,
			double[] result) {
		for (int i = 0; i < first.length; i++) {
			result[i] = first[i]/second[i];
		}
	}
	
	public static void VectorMutiplyVector(double[] first, double[] second,
			double[] result) {
		for (int i = 0; i < first.length; i++) {
			result[i] = first[i]*second[i];
		}
	}
	
	
	
	public static void vectorAdd(double[] first, double[] second,
			double[] result) {
		for (int i = 0; i < first.length; i++) {
			result[i] = first[i] + second[i];
		}
	}

	public static void vectorAdd(double[] first, double[] second) {
		for (int i = 0; i < first.length; i++) {
			first[i] = first[i] + second[i];
		}
	}

	// 閸氭垿鍣洪崙锟�
	public static void vectorSub(double[] first, double[] second,
			double[] result) {
		for (int i = 0; i < first.length; i++) {
			result[i] = first[i] - second[i];
		}
	}

	public static void vectorSub(double[] first, double[] second) {
		for (int i = 0; i < first.length; i++) {
			first[i] = first[i] - second[i];
		}
	}

	// 閸氭垿鍣烘稊锟�
	public static void vectorMutiply(double[] vector, double time,
			double[] result) {
		for (int i = 0; i < vector.length; i++) {
			result[i] = vector[i] * time;
		}
	}

	public static double[] vectorMutiply(double[] vector, double time) {
		double[] result = new double[vector.length];
		for (int i = 0; i < vector.length; i++) {
			result[i] = vector[i] * time;
		}
		return result;
	}

	public static double[] initZeroVector() {
		double[] result = new double[featureDimension];
		for (int i = 0; i < featureDimension; i++)
			result[i] = 0;
		return result;
	}

	public double getMinPrediction(int userID, int itemID) {
		double ratingHat = 0;
		ratingHat += dotMultiply(min_P[userID], min_Q[itemID]);
		if (flag_B) {
			for (int j = 0; j < B_Count; j++) {
				ratingHat += min_B[userID][j];
			}
		}
		if (flag_C) {
			for (int j = 0; j < C_Count; j++) {
				ratingHat += min_C[itemID][j];
			}
		}
		return ratingHat;
	}

	public double getLocPrediction(int userID, int itemID) {
		double ratingHat = 0;
		ratingHat += dotMultiply(P[userID], Q[itemID]);
//		if (flag_B) {
//			for (int j = 0; j < B_Count; j++) {
//				ratingHat += B[userID][j];
//			}
//		}
//		if (flag_C) {
//			for (int j = 0; j < C_Count; j++) {
//				ratingHat += C[itemID][j];
//			}
//		}
		return ratingHat;
	}
	
	

	public static void getUseBias(double u,double[] b,int[] r,double c,double[] B)
	{ 
		for(int i = 1; i <= item_MaxID; i++)
		{
			 if(r[i] == 0)
			     b[i] = 0;
			 else
			  {
				 B[i] = (b[i] - u * r[i])/(r[i]+c);
			  } 			
		}	
	}
	public static void getItemBias(double u,double[] b,int[] r,double c,double[] sum,double[] B)
	{ 
		for(int j = 1; j <= user_MaxID; j++)
		{			
			 if(r[j] == 0)
			    b[j] = 0;		 
			 else	 
			 {
				 B[j] = (b[j] - u * r[j] - sum[j])/(r[j]+c);
			 }	
			 
		}
	}
	
	
	public int getMaxIndex(double[] array) {
		int temp = -1;
		double max = -1000;
		for (int i = 0; i < array.length - 1; i++) {
			if (max < array[i]) {
				max = array[i];
				temp = i;
			}
		}
		return temp;
	}

	public double testCurrentMAEu(double []Bi,double []Bu,double u,double currentsrate) throws InterruptedException {
		double MAE;


		// 鐠侊紕鐣婚崷銊︾ゴ鐠囨洟娉︽稉濠勬畱MAE

			double sumMAE1 = 0, sumCount1 = 0;
			for (RTuple tempTestRating : testData) {
				double actualRating = tempTestRating.dRating - u - Bu[tempTestRating.iUserID] - Bi[tempTestRating.iItemID];
				double ratinghat = this.getLocPrediction(tempTestRating.iUserID,
						tempTestRating.iItemID);

				sumMAE1 += Math.abs(actualRating - ratinghat);
				sumCount1++;
			}
			MAE = sumMAE1 / sumCount1;


		return MAE;
		 
		
	}

	
	public double testCurrentRMSEu(double []Bi,double []Bu,double u,double currentsrate) throws InterruptedException {
		// 鐠侊紕鐣婚崷銊︾ゴ鐠囨洟娉︽稉濠勬畱RMSE
		double RMSE;

		{
			double sumRMSE1 = 0, sumCount1 = 0;
			for (RTuple tempTestRating : testData) {
				double actualRating = tempTestRating.dRating - u - Bu[tempTestRating.iUserID] - Bi[tempTestRating.iItemID];
				double ratinghat = this.getLocPrediction(tempTestRating.iUserID,
						tempTestRating.iItemID);

				sumRMSE1 += Math.pow((actualRating - ratinghat), 2);
				sumCount1++;
			}
			 RMSE = Math.sqrt(sumRMSE1 / sumCount1);
		}


		return RMSE;
				
	}

	public double testCurrentSumCount(double []Bi,double []Bu,double u)	//濞村鐦崷銊︾ゴ鐠囨洟娉︽稉濠咁吀缁犳娈戦弫鐗堝祦娑擃亝鏆�
	{
		// 鐠侊紕鐣婚崷銊︾ゴ鐠囨洟娉︽稉濠勬畱RMSE
		double  sumCount = 0;
		for (RTuple tempTestRating : testData)
		{
			sumCount++;
		}
		return sumCount;
				
	}
	
	// according the "e:\\UserClassId.txt" to split the original Dataset
    public static int  userclassid[]; //initialize the userclassid[],recording the each cluster's No and their counts
		public static int[] SplitDataset(int TypeOfClustering) throws NumberFormatException, IOException /// return each cluster's  counts
	{
        
			  FileReader reader = new FileReader("e:\\UserClassId.txt");   //猫庐掳氓陆鈥ser氓卤啪盲潞沤莽拧鈥灻甭幻ニ喡β犫�∶�
		      BufferedReader br = new BufferedReader(reader);   
		      String ClassLabel = null;   
		      
		      while((ClassLabel = br.readLine()) != null) 
		      {   

		    	  String newString = ClassLabel.replaceAll("\t", "");
	
		    	  char[] chars = newString.toCharArray();
		  
		    	  //int[] userclassid;
		    	  userclassid=new int[newString.length()];
                    
		      	   for(int j=0;j<chars.length;j++)
		      	   {                       
		      		 userclassid[j] = (int)chars[j]-48;
		      	     //System.out.println(userclassid[j] + "\t"); 
			       } 		   	  
		       }
		                 
            br.close();    
 
			
	        File file1 = new File("E:\\train1.txt");  //氓颅藴忙鈥澛久︹�⒙懊烩�灻︹�⒙懊︼拷庐莽拧鈥灻︹�撯�∶ぢ宦� 
			File file2 = new File("E:\\train2.txt");  //氓颅藴忙鈥澛久︹�⒙懊烩�灻︹�⒙懊︼拷庐莽拧鈥灻︹�撯�∶ぢ宦�  
			File file3 = new File("E:\\train3.txt"); 
			File file4 = new File("E:\\train4.txt");
			FileWriter out1 = new FileWriter(file1);  //忙鈥撯�∶ぢ宦睹モ�犫劉氓鈥βッβ碉拷
			FileWriter out2 = new FileWriter(file2);  //忙鈥撯�∶ぢ宦睹モ�犫劉氓鈥βッβ碉拷
			FileWriter out3 = new FileWriter(file3);  //忙鈥撯�∶ぢ宦睹モ�犫劉氓鈥βッβ碉拷
	   		FileWriter out4 = new FileWriter(file4);  //忙鈥撯�∶ぢ宦睹モ�犫劉氓鈥βッβ碉拷
	   		File file5 = new File("E:\\test1.txt");  //氓颅藴忙鈥澛久︹�⒙懊烩�灻︹�⒙懊︼拷庐莽拧鈥灻︹�撯�∶ぢ宦� 
    		File file6 = new File("E:\\test2.txt");  //氓颅藴忙鈥澛久︹�⒙懊烩�灻︹�⒙懊︼拷庐莽拧鈥灻︹�撯�∶ぢ宦�  
    		File file7 = new File("E:\\test3.txt"); 
    		File file8 = new File("E:\\test4.txt");
    		FileWriter out5 = new FileWriter(file5);  //忙鈥撯�∶ぢ宦睹モ�犫劉氓鈥βッβ碉拷
    		FileWriter out6 = new FileWriter(file6);  //忙鈥撯�∶ぢ宦睹モ�犫劉氓鈥βッβ碉拷
    		FileWriter out7 = new FileWriter(file7);  //忙鈥撯�∶ぢ宦睹モ�犫劉氓鈥βッβ碉拷
    		FileWriter out8 = new FileWriter(file8); 
	          
    
    		
	         for (RTuple tempRating : trainData)// 氓娄鈥毭ε九撁λ溌β碘�姑�⒚┾�衡�犆ヂ奥泵︼拷垄忙藛锟� testData
			{
	        	 
	       
			if (TypeOfClustering==1){
				if(userclassid[tempRating.iUserID-1]==1)// 氓娄鈥毭ε九撁λ溌疘tem氓掳卤忙锟铰⒚λ嗭拷 iItemID
       	         {
			    
	    		  out1.write(tempRating.iUserID +"::"+ tempRating.iItemID +"::"+ tempRating.dRating);
	    		  out1.write("\r\n");
	              }
  	 
  	            else if(userclassid[tempRating.iUserID-1]==2)
  	                  {
    		            out2.write(tempRating.iUserID +"::"+ tempRating.iItemID +"::"+ tempRating.dRating);
    		            out2.write("\r\n");
                      }        
  		 		  else if(userclassid[tempRating.iUserID-1]==3)
  	                  {
  		               out3.write(tempRating.iUserID +"::"+ tempRating.iItemID +"::"+ tempRating.dRating);
  		               out3.write("\r\n");
   	                  }   
  	          		 else 
  	                        {
	    		            out4.write(tempRating.iUserID +"::"+ tempRating.iItemID +"::"+ tempRating.dRating);
	    		           out4.write("\r\n");
                            }    	      			     	 	
	        	 	}
			if (TypeOfClustering!=1){
				if(userclassid[tempRating.iItemID-1]==1)// 氓娄鈥毭ε九撁λ溌疘tem氓掳卤忙锟铰⒚λ嗭拷 iItemID
       	         {
			    
	    		  out1.write(tempRating.iUserID +"::"+ tempRating.iItemID +"::"+ tempRating.dRating);
	    		  out1.write("\r\n");
	              }
  	 
  	            else if(userclassid[tempRating.iItemID-1]==2)
  	                  {
    		            out2.write(tempRating.iUserID +"::"+ tempRating.iItemID +"::"+ tempRating.dRating);
    		            out2.write("\r\n");
                      }        
  		 		  else if(userclassid[tempRating.iItemID-1]==3)
  	                  {
  		               out3.write(tempRating.iUserID +"::"+ tempRating.iItemID +"::"+ tempRating.dRating);
  		               out3.write("\r\n");
   	                  }   
  	          		 else 
  	                        {
	    		            out4.write(tempRating.iUserID +"::"+ tempRating.iItemID +"::"+ tempRating.dRating);
	    		           out4.write("\r\n");
                            }    	      			     	 	
	        	 	}
				}

	         
	         
	         int cluster1=0, cluster2=0, cluster3=0, cluster4=0;
	         for (RTuple tempRating : testData)// 氓娄鈥毭ε九撁λ溌β碘�姑�⒚┾�衡�犆ヂ奥泵︼拷垄忙藛锟� testData
				{
		        	 
		       
				if (TypeOfClustering==1){
					if(userclassid[tempRating.iUserID-1]==1)// 氓娄鈥毭ε九撁λ溌疘tem氓掳卤忙锟铰⒚λ嗭拷 iItemID
	       	         {
				    
		    		  out5.write(tempRating.iUserID +"::"+ tempRating.iItemID +"::"+ tempRating.dRating);
		    		  out5.write("\r\n");
		    		  cluster1=cluster1+1;
		    		  
		              }
	  	 
	  	            else if(userclassid[tempRating.iUserID-1]==2)
	  	                  {
	    		            out6.write(tempRating.iUserID +"::"+ tempRating.iItemID +"::"+ tempRating.dRating);
	    		            out6.write("\r\n");
	    		            cluster2=cluster2+1;
	                      }        
	  		 		  else if(userclassid[tempRating.iUserID-1]==3)
	  	                  {
	  		               out7.write(tempRating.iUserID +"::"+ tempRating.iItemID +"::"+ tempRating.dRating);
	  		               out7.write("\r\n");
	  		             cluster3=cluster3+1;
	   	                  }   
	  	          		 else 
	  	                        {
		    		            out8.write(tempRating.iUserID +"::"+ tempRating.iItemID +"::"+ tempRating.dRating);
		    		           out8.write("\r\n");
		    		           cluster4=cluster4+1;
	                            }    	      			     	 	
		        	 	}
				if (TypeOfClustering!=1){
					if(userclassid[tempRating.iItemID-1]==1)// 氓娄鈥毭ε九撁λ溌疘tem氓掳卤忙锟铰⒚λ嗭拷 iItemID
	       	         {
				    
		    		  out5.write(tempRating.iUserID +"::"+ tempRating.iItemID +"::"+ tempRating.dRating);
		    		  out5.write("\r\n");
		    		  cluster1=cluster1+1;
		              }
	  	 
	  	            else if(userclassid[tempRating.iItemID-1]==2)
	  	                  {
	    		            out6.write(tempRating.iUserID +"::"+ tempRating.iItemID +"::"+ tempRating.dRating);
	    		            out6.write("\r\n");
	    		            cluster2=cluster2+1;
	                      }        
	  		 		  else if(userclassid[tempRating.iItemID-1]==3)
	  	                  {
	  		               out7.write(tempRating.iUserID +"::"+ tempRating.iItemID +"::"+ tempRating.dRating);
	  		               out7.write("\r\n");
	  		              cluster3=cluster3+1;
	   	                  }   
	  	          		 else 
	  	                        {
		    		            out8.write(tempRating.iUserID +"::"+ tempRating.iItemID +"::"+ tempRating.dRating);
		    		           out8.write("\r\n");
		    		           cluster4=cluster4+1;
	                            }    	      			     	 	
		        	 	}
					}
     
 	            out1.close();
 			    out2.close();
 			    out3.close();
 			    out4.close();
                out5.close();
        		out6.close();
        		out7.close();
        		out8.close(); 
        		
        		int [] cluster_result= new int [4];
        	    cluster_result[0]=cluster1;
        	    cluster_result[1]=cluster2;
        	    cluster_result[2]=cluster3;
        	    cluster_result[3]=cluster4;
        	    return cluster_result;    }
		// Over: according the "e:\\UserClassId.txt" to split the original Dataset
	
		public double testCheck(double []Bi,double []Bu,double u) 
		{
			double sumMAE = 0; 
			for (RTuple tempTestRating : trainData)
			{
				double actualRating = tempTestRating.dRating-u-Bu[tempTestRating.iUserID]-Bi[tempTestRating.iItemID];
				double ratinghat = this.getLocPrediction(tempTestRating.iUserID,
						tempTestRating.iItemID);

//				sumMAE += (actualRating - ratinghat)*(actualRating - ratinghat);
				sumMAE += Math.abs(actualRating - ratinghat);
				
			}

			return sumMAE;			
		}
		
		public static double vectorL1(double[] input) {
			double sum = 0;
			for (int i = 0; i < input.length; i++) 
			{			
				sum+= Math.abs(input[i]) ;
			}
			return sum;
		}

		public static double[][] initposition(String fileName, String separator)
				throws NumberFormatException, IOException {
			ArrayList<PTuple> poo = new ArrayList<PTuple>();
			ArrayList<PTuple> po = new ArrayList<PTuple>();
			
			File personSource = new File(fileName);
			BufferedReader in = new BufferedReader(new FileReader(personSource));
			double[][] p = new double[user_MaxID][user_MaxID];
			String tempVoting;
			int Num_trainData=0;
			while (((tempVoting = in.readLine()) != null)) {
				StringTokenizer st = new StringTokenizer(tempVoting, separator);
				String personID = null;
				if (st.hasMoreTokens())
					personID = st.nextToken();
				String movieID = null;
				if (st.hasMoreTokens())
					movieID = st.nextToken();
				String personRating = null;
				if (st.hasMoreTokens())
					personRating = st.nextToken();
				int iUserID = Integer.valueOf(personID);
				int iItemID = Integer.valueOf(movieID);
				double dRating = Double.valueOf(personRating);
				// 鐠佹澘缍嶆稉瀣付婢堆呮畱itemid閸滃瘈serid閿涙稑娲滄稉绡縯emid閸滃瘈serid閺勵垵绻涚紒顓犳畱閿涘本澧嶆禒銉︽付婢堆呮畱itemid閸滃瘈serid娑旂喍鍞悰銊ょ啊閸氬嫯鍤滈惃鍕殶閻╋拷
				//user_MaxID = (user_MaxID > iUserID) ? user_MaxID : iUserID;
				//item_MaxID = (item_MaxID > iItemID) ? item_MaxID : iItemID;
				//double dRating = Double.valueOf(personRating);
				PTuple temp = new PTuple();
				//temp.iUserID = iUserID;
				//temp.iItemID = iItemID;
				//temp.dRating = dRating*times_magnification;
				poo.add(temp);
				p[iUserID-1][iItemID-1]=dRating;
				Num_trainData+=1;
				//rating_Max=(rating_Max > temp.dRating) ? rating_Max : temp.dRating;
				//rating_Min=(rating_Min < temp.dRating) ? rating_Min : temp.dRating;
			}
			

			
			double[][] position = new double[Num_trainData][2];
		    int  input_i=0; 
			 for(PTuple tempRating : poo)
				{ 
				 position [input_i][0]=tempRating.iUserID;
				 position [input_i][1]=tempRating.iItemID;
				 //RatingList[input_i]=tempRating.dRating;
				 input_i++;
				}	


				
			
					
		in.close();
		return p;
					
		}
		public static double[][] initl(String fileName, String separator)
				throws NumberFormatException, IOException {
			ArrayList<PTuple> poo = new ArrayList<PTuple>();
			ArrayList<PTuple> po = new ArrayList<PTuple>();
			String str="";
			File personSource = new File(fileName);
			BufferedReader in = new BufferedReader(new FileReader(personSource));
			double[][] position = new double[user_MaxID][user_MaxID];
			String tempVoting="";
			int Num_trainData=0;
			while ((tempVoting = in.readLine()) != null) {
				
				str=""+tempVoting;
				String[] s=str.split("::");
				for(int j=0;j<user_MaxID;j++)
				{
					position[Num_trainData][j]=Double.valueOf(s[j]);
				}
//				StringTokenizer st = new StringTokenizer(tempVoting, separator);
//				String personID = null;
//				if (st.hasMoreTokens())
//					personID = st.nextToken();
//				String movieID = null;
//				if (st.hasMoreTokens())
//					movieID = st.nextToken();
//				String personRating = null;
//				if (st.hasMoreTokens())
//					personRating = st.nextToken();
//				int iUserID = Integer.valueOf(personID);
//				int iItemID = Integer.valueOf(movieID);

				// 鐠佹澘缍嶆稉瀣付婢堆呮畱itemid閸滃瘈serid閿涙稑娲滄稉绡縯emid閸滃瘈serid閺勵垵绻涚紒顓犳畱閿涘本澧嶆禒銉︽付婢堆呮畱itemid閸滃瘈serid娑旂喍鍞悰銊ょ啊閸氬嫯鍤滈惃鍕殶閻╋拷
				//user_MaxID = (user_MaxID > iUserID) ? user_MaxID : iUserID;
				//item_MaxID = (item_MaxID > iItemID) ? item_MaxID : iItemID;
				//double dRating = Double.valueOf(personRating);
//				PTuple temp = new PTuple();
//				temp.iUserID = iUserID;
//				temp.iItemID = iItemID;
//				temp.dRating = dRating;
//				poo.add(temp);
				//position[iUserID-1][iItemID-1]=dRating;
				Num_trainData+=1;
				//rating_Max=(rating_Max > temp.dRating) ? rating_Max : temp.dRating;
				//rating_Min=(rating_Min < temp.dRating) ? rating_Min : temp.dRating;
			}
			

			
			//double[][] position = new double[35][35];
		    int  input_i=0; 
			 for(PTuple tempRating : poo)
				{ 
				 int m=tempRating.iUserID;
				 int n=tempRating.iItemID;
				 //position [input_i][n-1]=tempRating.dRating;
				 //position [input_i][1]=tempRating.iItemID;
				 //RatingList[input_i]=tempRating.dRating;
				 input_i++;
				}	


				
			
					
		in.close();
		return position;
					
		}
	   
}

	
	
	
	
	
	
	
