

import sun.misc.Contended;

import java.io.IOException;
import java.io.FileWriter;
import java.io.File;
import java.util.Arrays;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Main_Function extends Common_Function 
{   
	public static double[][] W;
	public static double[][] Wint;
	public static double belta1=0;
	public static double belta2=0;
	public static int N=0;
	public static int M=0;
	public static int k=0;
	public static double sampling=0;

	public Main_Function(int errorType) throws NumberFormatException, IOException
	{
		super();
		this.err_type = errorType;
		// TODO Auto-generated constructor stub
	}


	
	int m=1;// initial biases parameter




	   double alpha=0.5;//control the L1-norm and L2-norm
	   static double gmma=0;
	public void train() throws IOException, InterruptedException {
	    double sumRating = 0;        
		double sum = 0;               
		double Globalaverage=0;           
		double[] Bi = new double[item_MaxID+1];     
		double[] Bu = new double[user_MaxID+1];



		
		
		int[] Ri = new int[item_MaxID+1];                 
		int[] Ru = new int[user_MaxID+1];           
		double[] bi = new double[item_MaxID+1];     
		double[] bu = new double[user_MaxID+1];     
		double[] sumC = new double[user_MaxID+1];
		double Riave = 0;
		double Ruave = 0;
	
		
/// setting the tipping point of l1 or l2 norm in the smooth l1 norm		
		double indicator=1;// initial biases parameter
		if (rating_Max>50)indicator=rating_Max/5;
		else if (rating_Max>5)indicator=rating_Max/2;
		else indicator=1;
		final double smooth_l1_indicator=indicator;
//	    smooth_l1_indicator=rating_Max;  open this, the model= L2-norm only
		
		

		//////////////computing biases start//////////////////
		for(RTuple tempRating : trainData)
		{
			sumRating += tempRating.dRating;                      
		    sum ++;
		     Ri[tempRating.iItemID] ++;                             
		     bi[tempRating.iItemID] += tempRating.dRating;
		     Ru[tempRating.iUserID] ++;
		     bu[tempRating.iUserID] += tempRating.dRating;	   
		}
		double[] tempPu = new double[featureDimension];
		double[] tempDeltaPu = new double[featureDimension];
		double[] tempPu1 = new double[featureDimension];
		double[] tempQi1 = new double[featureDimension];
		double[] tempQi = new double[featureDimension];
		double[] tempDeltaQi = new double[featureDimension];
			
			for(int i = 1; i <= item_MaxID; i++)
			{
	               Riave += Ri[i];
			}
			    Riave = Riave/item_MaxID/20;
			    
			for(int j = 1; j <= user_MaxID; j++)
			{
	             Ruave += Ru[j]; 
			}
		        Ruave = Ruave/user_MaxID/20;	      

			switch(m)
			{
			case 1:{
				Globalaverage = 0;
				for(int i =1;i<item_MaxID;i++)
				{
					Bi[i]=0;
				}
				for(int j =1;j<user_MaxID;j++)
				{
					Bu[j]=0;
				}    
			}break;
			case 2:{
				Globalaverage = sumRating/sum;
				getUseBias(Globalaverage,bi,Ri,Riave,Bi);
				for(RTuple tempRating : trainData)
				{
			     	sumC[tempRating.iUserID] += Bi[tempRating.iItemID];   			       
				}
			    getItemBias(Globalaverage,bu,Ru,Ruave,sumC,Bu);    
			}break;
		
			}	
			
//			System.out.println("M:"+item_MaxID+ "N"+N);
		double SumLossCumulativeL1=0; double SumLossCumulativeL2=0;

		for (int round = 1; round <= trainingRound; round++)
		{
			  for (RTuple tempRating : trainData)   /// for each known entries of the HiDS matrix 
			{
				double  ratingHat= tempRating.dRating - Globalaverage - Bi[tempRating.iItemID] - Bu[tempRating.iUserID];
				double rPrediction = this.getLocPrediction(tempRating.iUserID, tempRating.iItemID);
				double err = ratingHat - rPrediction;


////////////smooth L1 as the base model/////////////////////////
				if (Math.abs(err) <= smooth_l1_indicator)///////open absolute err<=1
				{
					alpha = 0;
					vectorMutiply(P[tempRating.iUserID], (1 - eta * lambda1), tempPu); //eta_u
					vectorMutiply(Q[tempRating.iItemID], (1 - eta * lambda2), tempQi);//eta_i

					vectorMutiply(P[tempRating.iUserID], err * eta * (1 - alpha), tempDeltaPu);//eta_i
					vectorMutiply(Q[tempRating.iItemID], err * eta * (1 - alpha), tempDeltaQi);//eta_u

					vectorAdd(tempPu, tempDeltaQi, P[tempRating.iUserID]);
					vectorAdd(tempQi, tempDeltaPu, Q[tempRating.iItemID]);
				}


				if (err > smooth_l1_indicator)///////open absolute err>1
				{
					alpha = 1;
					vectorMutiply(P[tempRating.iUserID], (1 - eta * lambda1), tempPu); //eta_u
					vectorMutiply(Q[tempRating.iItemID], (1 - eta * lambda2), tempQi);//eta_i

					vectorMutiply(Q[tempRating.iItemID], alpha * eta, tempQi1);//eta_u
					vectorMutiply(P[tempRating.iUserID], alpha * eta, tempPu1);//eta_i

					vectorAdd(tempPu, tempQi1, P[tempRating.iUserID]);
					vectorAdd(tempQi, tempPu1, Q[tempRating.iItemID]);
				}


				if (err < (-(smooth_l1_indicator)))///////open absolute err<-1
				{
					alpha = 1;
					vectorMutiply(P[tempRating.iUserID], (1 - eta * lambda1), tempPu); //eta_u
					vectorMutiply(Q[tempRating.iItemID], (1 - eta * lambda2), tempQi);//eta_i

					vectorMutiply(Q[tempRating.iItemID], alpha * eta, tempQi1);//eta_u
					vectorMutiply(P[tempRating.iUserID], alpha * eta, tempPu1);//eta_i

					vectorSub(tempPu, tempQi1, P[tempRating.iUserID]);
					vectorSub(tempQi, tempPu1, Q[tempRating.iItemID]);
				}
               //////////Spatial relationship
              /*  double[] tempP1 = new double[featureDimension];
                double[] tempP2 = new double[featureDimension];
                double[] tempP3 = new double[featureDimension];
                double[] tempP4 = new double[featureDimension];
                double[] tempP5 = new double[featureDimension];
                for (int i = 0; i <M; i++)
                {
                    if (W[tempRating.iUserID-1][i]!=0){
                        vectorSub(P[tempRating.iUserID], P[i+1],tempP1);
                        vectorMutiply(tempP1,W[tempRating.iUserID-1][i], tempP2);
                        vectorAdd(tempP2, tempP3, tempP4);
                        tempP3=tempP4;
                    }

                }
                vectorMutiply(tempP4, eta*belta1, tempP5);
                vectorSub(P[tempRating.iUserID], tempP5, P[tempRating.iUserID]);*/
                //////////temporal relationship
               /* double[] tempQb1 = new double[featureDimension];
                double[] tempQb2 = new double[featureDimension];
                double[] tempQb3 = new double[featureDimension];
                double[] tempQb4 = new double[featureDimension];
                if (tempRating.iItemID-1>0){
                    vectorSub(Q[tempRating.iItemID], Q[tempRating.iItemID-1], tempQb1);
                    vectorMutiply(tempQb1,belta2*eta, tempQb2);
                }
                if (tempRating.iItemID+1<=item_MaxID){
                    vectorSub(Q[tempRating.iItemID], Q[tempRating.iItemID+1], tempQb3);
                    vectorMutiply(tempQb3,belta2*eta, tempQb4);
                }
                vectorSub(Q[tempRating.iItemID], tempQb2, Q[tempRating.iItemID]);
                vectorSub(Q[tempRating.iItemID], tempQb4, Q[tempRating.iItemID]);*/
                //////////temporal relationship
			}//end for train
			int NCpu = Runtime.getRuntime().availableProcessors();
			//System.out.println(NCpu);
			final int threadCount=NCpu/2;
			Thread[] threads=new Thread[threadCount];
			final int segment=trainData.size()/threadCount+1;

			CountDownLatch latch=new CountDownLatch(threadCount);
			for(int i=0;i<threadCount;i++){
				int currentThreadNum=i;
				threads[i]=new Thread(()->{

					for (int j = currentThreadNum * segment; j < (currentThreadNum + 1) * segment && j < trainData.size(); j++) {
						/*	double ratingHat = trainData.get(j).dRating;
							double rPrediction = this.getLocPrediction(trainData.get(j).iUserID, trainData.get(j).iItemID);
							double err = ratingHat - rPrediction;

						double[] tempPu = new double[featureDimension];
						//double[] tempDeltaPu = new double[featureDimension];
						double[] tempPu1 = new double[featureDimension];
						double[] tempQi1 = new double[featureDimension];
						double[] tempQi = new double[featureDimension];
						//double[] tempDeltaQi = new double[featureDimension];
////////////smooth L1 as the base model/////////////////////////
							if (Math.abs(err) <= smooth_l1_indicator)///////open absolute err<=1
							{
								alpha = 0;
								vectorMutiply(P[trainData.get(j).iUserID], (1 - eta * lambda1), tempPu); //eta_u
								vectorMutiply(Q[trainData.get(j).iItemID], (1 - eta * lambda2), tempQi);//eta_i
								vectorMutiply(P[trainData.get(j).iUserID], err * eta * (1 - alpha), tempPu1);//eta_i


								vectorMutiply(Q[trainData.get(j).iItemID], err * eta * (1 - alpha), tempQi1);//eta_u

								vectorAdd(tempPu, tempQi1, P[trainData.get(j).iUserID]);
								vectorAdd(tempQi, tempPu1, Q[trainData.get(j).iItemID]);
							}


							if (err > smooth_l1_indicator)///////open absolute err>1
							{
								alpha = 1;
								vectorMutiply(P[trainData.get(j).iUserID], (1 - eta * lambda1), tempPu); //eta_u
								vectorMutiply(Q[trainData.get(j).iItemID], (1 - eta * lambda2), tempQi);//eta_i

								vectorMutiply(Q[trainData.get(j).iItemID], alpha * eta, tempQi1);//eta_u
								vectorMutiply(P[trainData.get(j).iUserID], alpha * eta, tempPu1);//eta_i

								vectorAdd(tempPu, tempQi1, P[trainData.get(j).iUserID]);
								vectorAdd(tempQi, tempPu1, Q[trainData.get(j).iItemID]);
							}


							if (err < (-(smooth_l1_indicator)))///////open absolute err<-1
							{
								alpha = 1;
								vectorMutiply(P[trainData.get(j).iUserID], (1 - eta * lambda1), tempPu); //eta_u
								vectorMutiply(Q[trainData.get(j).iItemID], (1 - eta * lambda2), tempQi);//eta_i

								vectorMutiply(Q[trainData.get(j).iItemID], alpha * eta, tempQi1);//eta_u
								vectorMutiply(P[trainData.get(j).iUserID], alpha * eta, tempPu1);//eta_i

								vectorSub(tempPu, tempQi1, P[trainData.get(j).iUserID]);
								vectorSub(tempQi, tempPu1, Q[trainData.get(j).iItemID]);
							}*/




							/*	double[] tempP1 = new double[featureDimension];
								double[] tempP2 = new double[featureDimension];
								double[] tempP3 = new double[featureDimension];
								double[] tempP4 = new double[featureDimension];
								double[] tempP5 = new double[featureDimension];
								for (int inu = 0; inu <k; inu++) {

									{

										vectorSub(P[trainData.get(j).iUserID], P[inu + 1], tempP1);
										vectorMutiply(tempP1, W[trainData.get(j).iUserID - 1][inu], tempP2);
										vectorAdd(tempP2, tempP3, tempP4);
										tempP3 = tempP4;
									}

								}
								vectorMutiply(tempP4, eta * belta1, tempP5);
								vectorSub(P[trainData.get(j).iUserID], tempP5, P[trainData.get(j).iUserID]);*/
//
//
						//////////temporal relationship
						double[] tempQb1 = new double[featureDimension];
						double[] tempQb2 = new double[featureDimension];
						double[] tempQb3 = new double[featureDimension];
						double[] tempQb4 = new double[featureDimension];
						if (trainData.get(j).iItemID - 1 > 0) {
							vectorSub(Q[trainData.get(j).iItemID], Q[trainData.get(j).iItemID - 1], tempQb1);
							vectorMutiply(tempQb1, belta2 * eta, tempQb2);
						}
						if (trainData.get(j).iItemID + 1 <= item_MaxID) {
							vectorSub(Q[trainData.get(j).iItemID], Q[trainData.get(j).iItemID + 1], tempQb3);
							vectorMutiply(tempQb3, belta2 * eta, tempQb4);
						}
						vectorSub(Q[trainData.get(j).iItemID], tempQb2, Q[trainData.get(j).iItemID]);
						vectorSub(Q[trainData.get(j).iItemID], tempQb4, Q[trainData.get(j).iItemID]);
						//////temporal relationship
					}
					latch.countDown();

					//}


				});


			}
			for (Thread t : threads) {
				t.start();


			}

			latch.await();
                ////////testing start////////////
					double curErr;
					
						curErr = this.testCurrentRMSEu(Bi,Bu,Globalaverage,sampling);//RMSE
						if (min_Error_RMSE > curErr) 
						{
							min_Error_RMSE = curErr;
							this.min_Round = round;
						} 
						else if ((round - this.min_Round) >= delayCount)
						{
							break;
						}
						
				
						curErr = this.testCurrentMAEu(Bi,Bu,Globalaverage,sampling);//MAE
					
					if (min_Error_MAE > curErr) 
					{
						min_Error_MAE = curErr;
						this.min_Round = round;
					} 
					else if ((round - this.min_Round) >= delayCount)
					{
						break;
					}
					//System.out.println(m + "\t" + this.min_Round + "\t" + min_Error_RMSE+"\t" +"   "+min_Error_MAE);
		}
		
			
	}
	public static double[][] paixu(double[][] Wint,int M,int k){

		double[][] W1=new double[M][k];
		if(k==0)
			return W1;
		for (int i1 = 0; i1 < M; i1++) {
			int count=0;
			for (int i2 = 0; i2 < M-1; i2++) {
				double max=Wint[i1][i2];
				int row=i1;
				int col=i2;
				for(int i3=1;i3<M;i3++){
					if(max<Wint[i1][i3]){
						max=Wint[i1][i3];
						col=i3;
					}
				}
				W1[i1][count]=max;
				Wint[i1][col]=0;
				count++;
				if(count==k)
					break;
			}
		}
		return W1;
	}
     ////////////////////////main Function//////////////////////////////////
	public static void main(String[] argv) throws NumberFormatException, IOException, InterruptedException {

        for(int i = 0; i <=0; i++)//noise_ratio from 0%-50%
        {

//        Common_Function.noise_ratio=0;//control the noise_ratio 
        Common_Function.initializeRatings("./train.txt","./test.txt", "::");//input dataset
//        System.out.println("Max:"+rating_Max+"Min:"+rating_Min);
        
        int m=1;//1 means no Bias, 2 means Bias

    	N=item_MaxID;
    	M=user_MaxID;
      	Wint=Common_Function.initl("./W.txt","::");//load spatial relationship
		k=5;
		sampling=0.3;
			W = Main_Function.paixu(Wint, M, k);


			//for (int s =0; s <=4; s++)
    		//for (int t =0; t <=10; t++)
		{
			belta1=0.00;
			belta2=2;
			//double Fx=Math.pow(2, (t-1));//for adjusting featureDimension
			//	int Fxx = (int) Fx;//for adjusting featureDimension
			Common_Function.eta =1e-4;
			Common_Function.lambda1 =1e-2;
			Common_Function.lambda2=1e-2;
			Common_Function.trainingRound = 2000;
			Common_Function.delayCount = 20;
			Common_Function.featureDimension =50;
			Common_Function.sampliRate=0.5;
    			Common_Function.initiStaticArrays();
			      min_Error_RMSE = 1e8;
			      min_Error_MAE= 1e8;
			      Common_Function.initBiasSettings(true, true, 1, 1);
			      Main_Function mf_New_2 = new Main_Function(1);   
			      mf_New_2.m=m;

			     
			      long startTime=System.currentTimeMillis();
			     mf_New_2.train();
			      long endTime=System.currentTimeMillis();
			      double seconds=(endTime-startTime)/1000F;
			      System.out.println("belta1:"+belta1+ "\t  "+"belta2:"+belta2+ "\t  " +"lambda2:"+lambda2+ "\t  "+"RMSE:"+min_Error_RMSE+"\t"+"MAE:"+min_Error_MAE +"\t  "+"second:"+seconds+"\t  "+mf_New_2.min_Round );

			      
			      
       }


	}
  }
}















