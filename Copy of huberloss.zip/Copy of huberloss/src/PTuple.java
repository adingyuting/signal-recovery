
public class PTuple {
    public int iUserID = 0;
	
	public int iItemID = 0;
	public double dRating = 0;
	

}
